JohnnyRoyHFX1a.zip (May 24, 2003)

NOTE: You must have Hollywood FX 4.6 or higher to use these FX.

This is my first collection of nine (9) Hollywood FX I created with HFX Pro converted to the HFX 4.6 format. These FX were created to mimic the built in 3D FX of some NLE packages but not found in Studio 8. They include Cube Spin Left, Cube Spin Up, Domino Back, Slide Behind, Slide Up, Spiral In, Squeeze Right, Squeeze Up, & Swing N Drop. Nothing too fancy, but I find that makes them more useful in everyday work.

I especially like to use Slide Behind FX with titles. It gives the illusion of cue cards being flipped behind each other. These FX will only work with HFX Plus or HFX Pro.

Installation Notes:

The files in this ZIP package were created with the new Hollywood FX 4.6 ExportHFZ option. To install the .hfz files on any system with Hollywood FX 4.6 or higher: Double-click on the icon of the .hfz file. The HFZ Installer will load and install all of the files in the .hfz file. Click Ok to close the dialog when finished.

I hope you enjoy them.

John Rofrano
(aka JohnnyRoy)
john_rofrano@hotmail.com


